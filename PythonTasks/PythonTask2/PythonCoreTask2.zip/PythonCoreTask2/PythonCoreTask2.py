﻿#№1 print "To be or not to be , Shakespeare"  (with Escape Sequence).
print("1) To be\n\t  or not\n\t\t  to be \n \t\t\t /ShakeSpeare/")

print()
print()
print("===========================================================")
print()

#№2 print "Bell,Backspace,New line ..."  (with Escape Sequence).
print("2)\t\b\bEscape sequences \n\n\\a\t Bell (alert)\n\\b\t Backspace \n\\n\t Newline \n\\r\t Carriage return\n\\t\t Horizontal tab \n\\\\ \t Backslash \\ \n\\\"\t Double quotation mark \" \n\\\' \tSingle quotation mark \' ")

print() 
print()
print("===========================================================")
print()
print()

#№3 print " '\t', '\n', '\\', '\'', '\"' " (with Escape Sequence).
print("3)  \" \'\\t\', \'\\n\', \'\\\\\', \'\\\'\', \'\\\"\' \" ")

print()
print()
print("===========================================================")
print()
print()

#№4 print cube (without Escape Sequence).
print("4)            *******************************")
print("             *|                            **")
print("            * |                           * *")
print("           *  |                          *  *")
print("          *   |                         *   *")
print("         *    |                        *    *")
print("        *     |                       *     *")
print("       *******************************      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |                      *      *")
print("       *      |______________________*______*")
print("       *     /                       *     *")
print("       *    /                        *    *")
print("       *   /                         *   *")
print("       *  /                          *  *")
print("       * /                           * *")
print("       */                            **")
print("       *******************************")

