﻿#==================Task 1=====================#

# Kvadratın tərəfini daxil edib, ulduzlarla ekrana kvadrat çıxar.

"""
number=int(input("Enter The Number: "))

for i in range(number):
    for k in range(number):
        if(i==0 or 0<i<number and k==number-1 or k==0 or i==number-1):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
"""


    
#==================Task 2=====================#

# Kvadratın tərəfini daxil edib, ulduzlarla ekrana pəncərə çıxar.

"""
number=int(input("Enter The Number: "))

for i in range(number):
    for k in range(number):
        if(i==0 or 0<i<number and k==number-1 or k==0 or
           i==(number-1)//2 or k==(number-1)//2 or i==number-1):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
"""



#==================Task 3=====================#

# Kvadratın tərəfini daxil edib, ulduzlarla ekrana xaç çıxar.
 
"""
number=int(input("Enter The Number: "))

for i in range(number):
    for k in range(number):
        if(i==0 or i==number-1 and k<=number or k==0 or k==number-1 and i<=number 
           or (k==5 or k==number-6) and (i<=5 or i>=number-6) 
           or (i==5 or i==number-6) and (k<=5 or k>=number-6) ):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
"""



#==================Task 4=====================#

# Kvadratın tərəfini daxil edib, ulduzlarla ekrana zərf çıxar. 

"""
number=int(input("Enter The Number: "))

for i in range(number):
    for k in range(number):
        if(i==0 or 0<i<number and k==number-1 or k==0 or i==number-1 or i==k or i+k==number-1):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
"""




