﻿#Task1(3 Ədəd daxil et , onların cəmi və hasili)
"""
num1=float(input("Enter the first number: "))
num2=float(input("Enter the second number: "))
num3=float(input("Enter the third number: "))

summ=num1+num2+num3
multi=num1*num2*num3
print(f"==========================\nThe Sum of The Numbers: {summ} \nThe Multiplication of The Numbers: {multi} ")
"""

#Task2(Əmək haqqı , Bank krediti , Kommunal xidmətlər)
"""
salary=float(input("Enter Your Salary: "))   #əmək haqqı 
loans=float(input("Enter Your Loans: "))    #bank krediti  
services=float(input("Enter Your Services: ")) #kommunal servislər

residue=salary-loans-services
print(f"==========================\n\n {salary} \n- \n {loans} \n- \n {services} \n--------\n {residue} \n\n Your Residue: {residue}")
"""

#Task3(Rombun sahəsi)
"""
dioganal1=float(input("Enter the first dioganal: "))
dioganal2=float(input("Enter the second dioganal: "))

AreaOfRhombus=(dioganal1+dioganal2)/2
print(f"========================== \nThe Area of Rhombus: {AreaOfRhombus}")
"""